use std::f64::consts::PI;
use lazy_static::lazy_static;
use std::io;

const LUT_SIZE: usize = 91;

lazy_static! {
    static ref SIN_LUT: [f64; LUT_SIZE] = {
        let mut table = [0.0; LUT_SIZE];
        for i in 0..LUT_SIZE {
            table[i] = (i as f64 * PI / 180.0).sin();
        }
        table
    };

    static ref COS_LUT: [f64; LUT_SIZE] = {
        let mut table = [0.0; LUT_SIZE];
        for i in 0..LUT_SIZE {
            table[i] = (i as f64 * PI / 180.0).cos();
        }
        table
    };
}

fn sine(deg: f64) -> f64 {
    let deg = deg.rem_euclid(360.0);
    let index = deg.round() as usize;
    if index <= 90 {
        SIN_LUT[index]
    } else if index <= 180 {
        SIN_LUT[180 - index]
    } else if index <= 270 {
        -SIN_LUT[index - 180]
    } else {
        -SIN_LUT[360 - index]
    }
}

fn cosine(deg: f64) -> f64 {
    let deg = deg.rem_euclid(360.0);
    let index = deg.round() as usize;
    if index <= 90 {
        COS_LUT[index]
    } else if index <= 180 {
        -COS_LUT[180 - index]
    } else if index <= 270 {
        -COS_LUT[index - 180]
    } else {
        COS_LUT[360 - index]
    }
}

fn main() {
    let mut input = String::new();
    println!("Masukkan sudut dalam derajat: ");
    io::stdin().read_line(&mut input).expect("Gagal membaca input");
    let angle_deg: f64 = input.trim().parse().expect("Harap masukkan angka yang valid");
    
    println!("sin({}) ≈ {:.6}", angle_deg, sine(angle_deg));
    println!("cos({}) ≈ {:.6}", angle_deg, cosine(angle_deg));
}
