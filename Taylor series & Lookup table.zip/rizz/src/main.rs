use std::f64::consts::PI;

// Fungsi untuk menghitung faktorial
fn factorial(n: u64) -> u64 {
    (1..=n).product()
}

// Fungsi untuk menghitung sinus menggunakan deret Taylor
fn sine(x: f64, terms: u32) -> f64 {
    let mut result = 0.0;
    for n in 0..terms {
        let term = ((-1.0f64).powi(n as i32) * x.powi(2 * n as i32 + 1)) / factorial((2 * n + 1) as u64) as f64;
        result += term;
    }
    result
}

// Fungsi untuk menghitung kosinus menggunakan deret Taylor
fn cosine(x: f64, terms: u32) -> f64 {
    let mut result = 0.0;
    for n in 0..terms {
        let term = ((-1.0f64).powi(n as i32) * x.powi(2 * n as i32)) / factorial((2 * n) as u64) as f64;
        result += term;
    }
    result
}

fn main() {
    let angle_deg = 30.0; // Sudut dalam derajat
    let angle_rad = angle_deg * PI / 180.0; // Konversi ke radian
    let terms = 10; // Jumlah suku dalam deret Taylor
    
    println!("sin({}) ≈ {:.6}", angle_deg, sine(angle_rad, terms));
    println!("cos({}) ≈ {:.6}", angle_deg, cosine(angle_rad, terms));
}
