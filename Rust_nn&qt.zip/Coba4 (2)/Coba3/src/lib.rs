use ndarray::array;
use ndarray::{Array, Array1, Array2, Axis, s};
use ndarray_rand::RandomExt;
use ndarray_rand::rand_distr::Uniform;
use serde::{Serialize, Deserialize};
use std::error::Error;
use csv::Reader;
use plotters::prelude::*;

// Structures
#[derive(Serialize, Deserialize)]
pub struct TrainingHistory {
    pub epochs: Vec<usize>,
    pub accuracies: Vec<f64>,
    pub losses: Vec<f64>,
}

#[derive(Serialize, Deserialize)]
pub struct TrainedModel {
    pub network: NeuralNetwork,
    pub x_mean: Array1<f64>,
    pub x_std: Array1<f64>,
    pub class_weights: Vec<f64>,
}

#[derive(Serialize, Deserialize)]
pub struct NeuralNetwork {
    pub weights1: Array2<f64>,
    pub bias1: Array2<f64>,
    pub weights2: Array2<f64>,
    pub bias2: Array2<f64>,
    pub dropout_rate: f64,
}

#[derive(Serialize, Deserialize)]
pub struct PredictionResult {
    pub class: usize,
    pub probabilities: Vec<f64>,
}

// Public API functions
#[unsafe(no_mangle)]
pub extern "C" fn train_and_save_model(
    csv_path: *const libc::c_char,
    model_path: *const libc::c_char,
    plot_path: *const libc::c_char,
    epochs: usize,
) -> bool {
    let csv_path_str = unsafe { std::ffi::CStr::from_ptr(csv_path).to_str().unwrap() };
    let model_path_str = unsafe { std::ffi::CStr::from_ptr(model_path).to_str().unwrap() };
    let plot_path_str = unsafe { std::ffi::CStr::from_ptr(plot_path).to_str().unwrap() };

    match train_model(csv_path_str, epochs, plot_path_str) {
        Ok(model) => {
            if let Ok(model_data) = bincode::serialize(&model) {
                std::fs::write(model_path_str, model_data).is_ok()
            } else {
                false
            }
        }
        Err(_) => false,
    }
}

type TrainingCallback = extern "C" fn(epoch: i32, accuracy: f64, loss: f64);

static mut CALLBACK: Option<TrainingCallback> = None;

#[unsafe(no_mangle)]
pub extern "C" fn set_training_callback(callback: TrainingCallback) {
    unsafe {
        CALLBACK = Some(callback);
    }
}

#[unsafe(no_mangle)]
pub extern "C" fn load_model(model_path: *const libc::c_char) -> *mut TrainedModel {
    let model_path_str = unsafe { std::ffi::CStr::from_ptr(model_path).to_str().unwrap() };
    
    match std::fs::read(model_path_str) {
        Ok(model_data) => {
            match bincode::deserialize::<TrainedModel>(&model_data) {
                Ok(model) => Box::into_raw(Box::new(model)),
                Err(_) => std::ptr::null_mut(),
            }
        }
        Err(_) => std::ptr::null_mut(),
    }
}

#[unsafe(no_mangle)]
pub extern "C" fn free_model(model: *mut TrainedModel) {
    if !model.is_null() {
        unsafe { let _ = Box::from_raw(model); };
    }
}

#[unsafe(no_mangle)]
pub extern "C" fn predict_failure(
    model: *const TrainedModel,
    air_temp: f64,
    process_temp: f64,
    rotational_speed: f64,
    torque: f64,
    tool_wear: f64,
) -> *mut PredictionResult {
    if model.is_null() {
        return std::ptr::null_mut();
    }

    let model = unsafe { &*model };
    let result = predict(
        air_temp,
        process_temp,
        rotational_speed,
        torque,
        tool_wear,
        &model.network,
        &model.x_mean,
        &model.x_std,
    );

    Box::into_raw(Box::new(result))
}

#[unsafe(no_mangle)]
pub extern "C" fn free_prediction_result(result: *mut PredictionResult) {
    if !result.is_null() {
        unsafe { let _ = Box::from_raw(result); };
    }
}

#[unsafe(no_mangle)]
pub extern "C" fn get_prediction_class(result: *const PredictionResult) -> usize {
    if result.is_null() {
        return 0;
    }
    unsafe { (*result).class }
}

#[unsafe(no_mangle)]
pub extern "C" fn get_prediction_probability(result: *const PredictionResult, class: usize) -> f64 {
    if result.is_null() || class >= 5 {
        return 0.0;
    }
    unsafe { (*result).probabilities[class] }
}

// === TRAINING FUNCTION ===
fn train_model(
    csv_path: &str,
    epochs: usize,
    plot_path: &str,
) -> Result<TrainedModel, Box<dyn Error>> {
    // Load data
    let (x, y, class_counts) = load_data(csv_path)?;
    println!("Class distribution: {:?}", class_counts);
    
    // Split data
    let split_idx = (x.shape()[0] as f64 * 0.8) as usize;
    let x_train = x.slice(s![..split_idx, ..]).to_owned();
    let y_train = y.slice(s![..split_idx, ..]).to_owned();
    let x_test = x.slice(s![split_idx.., ..]).to_owned();
    let y_test = y.slice(s![split_idx.., ..]).to_owned();

    // Calculate normalization parameters
    let x_mean = x_train.mean_axis(Axis(0)).unwrap();
    let x_std = x_train.std_axis(Axis(0), 1.0).mapv(|v| if v == 0.0 { 1.0 } else { v });
    
    // Normalize data
    let x_train_norm = (x_train - &x_mean) / &x_std;
    let x_test_norm = (x_test - &x_mean) / &x_std;

    // Calculate class weights
    let class_weights = calculate_class_weights(&class_counts);
    println!("Class weights: {:?}", class_weights);

    // Initialize network
    let input_size = x_train_norm.shape()[1];
    let hidden_size = 16;
    let output_size = y_train.shape()[1];
    let mut nn = NeuralNetwork::new(input_size, hidden_size, output_size, 0.3);

    let mut history = TrainingHistory {
        epochs: Vec::new(),
        accuracies: Vec::new(),
        losses: Vec::new(),
    };

    for epoch in 0..epochs {
        let lr = 0.001 * (1.0 / (1.0 + 0.01 * epoch as f64));
        
        // Train
        nn.train(&x_train_norm, &y_train, lr, &class_weights);

        // Evaluate on test set
        let (_, _, output) = nn.forward(&x_test_norm);
        let accuracy = calculate_accuracy(&y_test, &output);
        let loss = weighted_cross_entropy(&y_test, &output, &class_weights);

        // Call the callback function if it's set
        unsafe {
            if let Some(cb) = CALLBACK {
                cb(epoch as i32, accuracy, loss);
            }
        }

        if epoch % 100 == 0 {
            println!("Epoch {} - Loss: {:.4} - Test Accuracy: {:.2}%", 
                epoch, loss, accuracy * 100.0);
            history.epochs.push(epoch);
            history.accuracies.push(accuracy);
            history.losses.push(loss);
        }
    }

    // Final evaluation
    let (_, _, final_output) = nn.forward(&x_test_norm);
    let final_accuracy = calculate_accuracy(&y_test, &final_output);
    println!("✅ Final Test Accuracy: {:.2}%", final_accuracy * 100.0);

    create_training_plot(&history, plot_path)?;

    Ok(TrainedModel {
        network: nn,
        x_mean,
        x_std,
        class_weights,
    })
}

// === NEURAL NETWORK IMPLEMENTATION ===
impl NeuralNetwork {
    fn new(input_size: usize, hidden_size: usize, output_size: usize, dropout_rate: f64) -> Self {
        let he_init = |size: usize| (2.0 / size as f64).sqrt();

        Self {
            weights1: Array::random(
                (input_size, hidden_size),
                Uniform::new(-he_init(input_size), he_init(input_size)),
            ),
            bias1: Array::zeros((1, hidden_size)),
            weights2: Array::random(
                (hidden_size, output_size),
                Uniform::new(-he_init(hidden_size), he_init(hidden_size)),
            ),
            bias2: Array::zeros((1, output_size)),
            dropout_rate,
        }
    }

    fn forward(&self, x: &Array2<f64>) -> (Array2<f64>, Array2<f64>, Array2<f64>) {
        let hidden_input = x.dot(&self.weights1) + &self.bias1;
        let hidden_output = relu(&hidden_input);
        let output_input = hidden_output.dot(&self.weights2) + &self.bias2;
        let output_output = softmax(&output_input);
        (hidden_input, hidden_output, output_output)
    }
    
    fn train(&mut self, x: &Array2<f64>, y: &Array2<f64>, lr: f64, class_weights: &[f64]) {
        let (_hidden_input, hidden_output, output) = self.forward(x);
        let output_error = &output - y;
        let weighted_error = output_error * Array::from_shape_vec(
            (1, class_weights.len()),
            class_weights.to_vec(),
        ).unwrap();
        let output_delta = &weighted_error;
        let hidden_error = output_delta.dot(&self.weights2.t());
        let hidden_delta = hidden_error * relu_derivative(&hidden_output);

        self.weights2 -= &(lr * hidden_output.t().dot(output_delta));
        self.bias2 -= &(lr * output_delta.sum_axis(Axis(0)).insert_axis(Axis(0)));

        self.weights1 -= &(lr * x.t().dot(&hidden_delta));
        self.bias1 -= &(lr * hidden_delta.sum_axis(Axis(0)).insert_axis(Axis(0)));
    }
}

// === HELPER FUNCTIONS ===
fn load_data(path: &str) -> Result<(Array2<f64>, Array2<f64>, [usize; 5]), Box<dyn Error>> {
    let mut rdr = Reader::from_path(path)?;
    let mut inputs = Vec::new();
    let mut outputs = Vec::new();
    let mut class_counts = [0; 5];

    for result in rdr.records() {
        let record = result?;
        let input: Vec<f64> = (0..5).map(|i| record[i].parse::<f64>().unwrap()).collect();
        let label = match record[5].as_ref() {
            "No Failure" => 0,
            "Heat Dissipation Failure" => 1,
            "Power Failure" => 2,
            "Random Failures" => 3,
            "Tool Wear Failure" => 4,
            _ => 0,
        };
        class_counts[label] += 1;
        inputs.push(input);
        outputs.push(one_hot_encode(label, 5));
    }

    Ok((
        Array2::from_shape_vec((inputs.len(), 5), inputs.concat())?,
        Array2::from_shape_vec((outputs.len(), 5), outputs.concat())?,
        class_counts,
    ))
}

fn one_hot_encode(label: usize, num_classes: usize) -> Vec<f64> {
    let mut vec = vec![0.0; num_classes];
    vec[label] = 1.0;
    vec
}

fn calculate_class_weights(class_counts: &[usize; 5]) -> Vec<f64> {
    let total = class_counts.iter().sum::<usize>() as f64;
    class_counts.iter()
        .map(|&count| total / (class_counts.len() as f64 * count as f64))
        .collect()
}

fn relu(x: &Array2<f64>) -> Array2<f64> {
    x.mapv(|v| v.max(0.0))
}

fn relu_derivative(x: &Array2<f64>) -> Array2<f64> {
    x.mapv(|v| if v > 0.0 { 1.0 } else { 0.0 })
}

fn softmax(x: &Array2<f64>) -> Array2<f64> {
    let max_x = x.fold_axis(Axis(1), f64::NEG_INFINITY, |&a, &b| a.max(b));
    let exp_x = (x - &max_x.insert_axis(Axis(1))).mapv(f64::exp);
    let sum_exp_x = exp_x.sum_axis(Axis(1)).insert_axis(Axis(1));
    exp_x / sum_exp_x
}

fn weighted_cross_entropy(y_true: &Array2<f64>, y_pred: &Array2<f64>, weights: &[f64]) -> f64 {
    let mut loss = 0.0;
    for i in 0..y_true.shape()[0] {
        for j in 0..y_true.shape()[1] {
            loss -= weights[j] * y_true[[i, j]] * (y_pred[[i, j]].max(1e-15)).ln();
        }
    }
    loss / y_true.shape()[0] as f64
}

fn calculate_accuracy(y_true: &Array2<f64>, y_pred: &Array2<f64>) -> f64 {
    let predictions = y_pred.map_axis(Axis(1), |row| {
        row.iter().enumerate().max_by(|a, b| a.1.partial_cmp(b.1).unwrap()).unwrap().0
    });
    let true_labels = y_true.map_axis(Axis(1), |row| {
        row.iter().enumerate().max_by(|a, b| a.1.partial_cmp(b.1).unwrap()).unwrap().0
    });
    predictions.iter().zip(true_labels.iter())
        .filter(|(p, t)| p == t)
        .count() as f64 / predictions.len() as f64
}

// === PREDICTION INTERFACE ===
fn predict(
    air_temp: f64,
    process_temp: f64,
    rotational_speed: f64,
    torque: f64,
    tool_wear: f64,
    nn: &NeuralNetwork,
    x_mean: &Array1<f64>,
    x_std: &Array1<f64>,
) -> PredictionResult {
    let input = array![[air_temp, process_temp, rotational_speed, torque, tool_wear]];
    let input_norm = (input - x_mean) / x_std;

    let (_, _, output) = nn.forward(&input_norm);
    let probs = output.row(0).to_vec();

    let class = probs.iter()
        .enumerate()
        .max_by(|a, b| a.1.partial_cmp(b.1).unwrap())
        .unwrap()
        .0;

    PredictionResult {
        class,
        probabilities: probs,
    }
}

// === PLOT TRAINING CURVE ===
fn create_training_plot(history: &TrainingHistory, path: &str) -> Result<(), Box<dyn Error>> {
    let root = BitMapBackend::new(path, (800, 480)).into_drawing_area();
    root.fill(&WHITE)?;

    let max_loss = history.losses.iter().cloned().fold(f64::MIN, f64::max);
    let max_accuracy = history.accuracies.iter().cloned().fold(f64::MIN, f64::max);

    let (loss_area, acc_area) = root.split_vertically(240);

    // Plot Loss
    let mut loss_chart = ChartBuilder::on(&loss_area)
        .caption("Training Loss", ("sans-serif", 20))
        .margin(10)
        .x_label_area_size(30)
        .y_label_area_size(40)
        .build_cartesian_2d(
            *history.epochs.first().unwrap()..*history.epochs.last().unwrap(),
            0.0..max_loss * 1.1,
        )?;

    loss_chart.configure_mesh().draw()?;
    loss_chart.draw_series(LineSeries::new(
        history.epochs.iter().zip(history.losses.iter()).map(|(&x, &y)| (x, y)),
        &RED,
    ))?
    .label("Loss")
    .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &RED));

    // Plot Accuracy
    let mut acc_chart = ChartBuilder::on(&acc_area)
        .caption("Training Accuracy", ("sans-serif", 20))
        .margin(10)
        .x_label_area_size(30)
        .y_label_area_size(40)
        .build_cartesian_2d(
            *history.epochs.first().unwrap()..*history.epochs.last().unwrap(),
            0.0..max_accuracy * 1.1,
        )?;

    acc_chart.configure_mesh().draw()?;
    acc_chart.draw_series(LineSeries::new(
        history.epochs.iter().zip(history.accuracies.iter()).map(|(&x, &y)| (x, y)),
        &BLUE,
    ))?
    .label("Accuracy")
    .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &BLUE));

    // Optional: Add legends
    loss_chart.configure_series_labels().background_style(&WHITE.mix(0.8)).border_style(&BLACK).draw()?;
    acc_chart.configure_series_labels().background_style(&WHITE.mix(0.8)).border_style(&BLACK).draw()?;

    Ok(())
}