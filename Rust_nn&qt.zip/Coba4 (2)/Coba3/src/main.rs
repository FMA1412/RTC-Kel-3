use ndarray::array;
use ndarray::{Array, Array1, Array2, Axis, s};
use ndarray_rand::RandomExt;
use ndarray_rand::rand_distr::Uniform;
use std::io::{self, Write};
use serde::{Serialize, Deserialize};
use std::error::Error;
use csv::Reader;
use std::path::Path;
use plotters::prelude::*;
use plotters::style::{BLACK, BLUE, RED, WHITE};


// Structures
#[derive(Serialize, Deserialize)]
struct TrainingHistory {
    epochs: Vec<usize>,
    accuracies: Vec<f64>,
    losses: Vec<f64>,
}

#[derive(Serialize, Deserialize)]
struct TrainedModel {
    network: NeuralNetwork,
    x_mean: Array1<f64>,
    x_std: Array1<f64>,
    class_weights: Vec<f64>,
}

#[derive(Serialize, Deserialize)]
struct NeuralNetwork {
    weights1: Array2<f64>,
    bias1: Array2<f64>,
    weights2: Array2<f64>,
    bias2: Array2<f64>,
    dropout_rate: f64,
}

struct PredictionResult {
    class: usize,
    probabilities: Vec<f64>,
}

// === MAIN FUNCTION ===
fn main() -> Result<(), Box<dyn Error>> {
    println!("🔧 Starting Predictive Maintenance System");

    let csv_path = "csv/predictive_maintenance.csv";
    let model_path = "model/trained_model.bin";
    let plot_path = "plots/training.png";
    let epochs = 2000;

    std::fs::create_dir_all("model")?;
    std::fs::create_dir_all("plots")?;
    std::fs::create_dir_all("csv")?;

    let trained_model = if Path::new(model_path).exists() {
        println!("📂 Loading existing model...");
        let model_data = std::fs::read(model_path)?;
        bincode::deserialize(&model_data)?
    } else {
        println!("🎓 Training new model...");
        let model = train_model(csv_path, epochs, plot_path)?;
        let model_data = bincode::serialize(&model)?;
        std::fs::write(model_path, model_data)?;
        model
    };

    run_prediction_loop(&trained_model)?;

    Ok(())
}

// === TRAINING FUNCTION ===
fn train_model(
    csv_path: &str,
    epochs: usize,
    plot_path: &str,
) -> Result<TrainedModel, Box<dyn Error>> {
    // Load data
    let (x, y, class_counts) = load_data(csv_path)?;
    println!("Class distribution: {:?}", class_counts);
    
    // Split data FIRST (80% train, 20% test)
    let split_idx = (x.shape()[0] as f64 * 0.8) as usize;
    let x_train = x.slice(s![..split_idx, ..]).to_owned();
    let y_train = y.slice(s![..split_idx, ..]).to_owned();
    let x_test = x.slice(s![split_idx.., ..]).to_owned();
    let y_test = y.slice(s![split_idx.., ..]).to_owned();

    // Calculate normalization parameters ONLY from training data
    let x_mean = x_train.mean_axis(Axis(0)).unwrap();
    let x_std = x_train.std_axis(Axis(0), 1.0).mapv(|v| if v == 0.0 { 1.0 } else { v });
    
    // Normalize both train and test using training statistics
    let x_train_norm = (x_train - &x_mean) / &x_std;
    let x_test_norm = (x_test - &x_mean) / &x_std;

    // Calculate class weights
    let class_weights = calculate_class_weights(&class_counts);
    println!("Class weights: {:?}", class_weights);

    // Initialize network
    let input_size = x_train_norm.shape()[1];
    let hidden_size = 16;
    let output_size = y_train.shape()[1];
    let mut nn = NeuralNetwork::new(input_size, hidden_size, output_size, 0.3);

    let mut history = TrainingHistory {
        epochs: Vec::new(),
        accuracies: Vec::new(),
        losses: Vec::new(),
    };

    for epoch in 0..epochs {
        let lr = 0.001 * (1.0 / (1.0 + 0.01 * epoch as f64));
        
        // Train
        nn.train(&x_train_norm, &y_train, lr, &class_weights);

        // Evaluate on test set
        let (_, _, output) = nn.forward(&x_test_norm);
        let accuracy = calculate_accuracy(&y_test, &output);
        let loss = weighted_cross_entropy(&y_test, &output, &class_weights);

        if epoch % 100 == 0 {
            println!("Epoch {} - Loss: {:.4} - Test Accuracy: {:.2}%", 
                epoch, loss, accuracy * 100.0);
            history.epochs.push(epoch);
            history.accuracies.push(accuracy);
            history.losses.push(loss);
        }
    }

    // Final evaluation
    let (_, _, final_output) = nn.forward(&x_test_norm);
    let final_accuracy = calculate_accuracy(&y_test, &final_output);
    println!("✅ Final Test Accuracy: {:.2}%", final_accuracy * 100.0);

    // Debug predictions
    println!("Sample predictions vs true labels:");
    for i in 0..5.min(y_test.shape()[0]) {
        let pred = final_output.row(i).iter()
            .enumerate()
            .max_by(|a, b| a.1.partial_cmp(b.1).unwrap())
            .unwrap().0;
        let true_label = y_test.row(i).iter()
            .enumerate()
            .max_by(|a, b| a.1.partial_cmp(b.1).unwrap())
            .unwrap().0;
        println!("Pred: {} vs True: {}", pred, true_label);
    }

    create_training_plot(&history, plot_path)?;

    Ok(TrainedModel {
        network: nn,
        x_mean,
        x_std,
        class_weights,
    })
}

// === NEURAL NETWORK IMPLEMENTATION ===
impl NeuralNetwork {
    fn new(input_size: usize, hidden_size: usize, output_size: usize, dropout_rate: f64) -> Self {
        let he_init = |size: usize| (2.0 / size as f64).sqrt();

        Self {
            weights1: Array::random(
                (input_size, hidden_size),
                Uniform::new(-he_init(input_size), he_init(input_size)),
            ),
            bias1: Array::zeros((1, hidden_size)),
            weights2: Array::random(
                (hidden_size, output_size),
                Uniform::new(-he_init(hidden_size), he_init(hidden_size)),
            ),
            bias2: Array::zeros((1, output_size)),
            dropout_rate,
        }
    }

    fn forward(&self, x: &Array2<f64>) -> (Array2<f64>, Array2<f64>, Array2<f64>) {
        let hidden_input = x.dot(&self.weights1) + &self.bias1;
        let hidden_output = relu(&hidden_input);
        let output_input = hidden_output.dot(&self.weights2) + &self.bias2;
        let output_output = softmax(&output_input);
        (hidden_input, hidden_output, output_output)
    }
    
    fn train(&mut self, x: &Array2<f64>, y: &Array2<f64>, lr: f64, class_weights: &[f64]) {
        let (_hidden_input, hidden_output, output) = self.forward(x);
        let output_error = &output - y;
        let weighted_error = output_error * Array::from_shape_vec(
            (1, class_weights.len()),
            class_weights.to_vec(),
        ).unwrap();
        let output_delta = &weighted_error;
        let hidden_error = output_delta.dot(&self.weights2.t());
        let hidden_delta = hidden_error * relu_derivative(&hidden_output);

        self.weights2 -= &(lr * hidden_output.t().dot(output_delta));
        self.bias2 -= &(lr * output_delta.sum_axis(Axis(0)).insert_axis(Axis(0)));

        self.weights1 -= &(lr * x.t().dot(&hidden_delta));
        self.bias1 -= &(lr * hidden_delta.sum_axis(Axis(0)).insert_axis(Axis(0)));
    }
}

// === HELPER FUNCTIONS ===
fn load_data(path: &str) -> Result<(Array2<f64>, Array2<f64>, [usize; 5]), Box<dyn Error>> {
    let mut rdr = Reader::from_path(path)?;
    let mut inputs = Vec::new();
    let mut outputs = Vec::new();
    let mut class_counts = [0; 5];

    for result in rdr.records() {
        let record = result?;
        let input: Vec<f64> = (0..5).map(|i| record[i].parse::<f64>().unwrap()).collect();
        let label = match record[5].as_ref() {
            "No Failure" => 0,
            "Heat Dissipation Failure" => 1,
            "Power Failure" => 2,
            "Random Failures" => 3,
            "Tool Wear Failure" => 4,
            _ => 0,
        };
        class_counts[label] += 1;
        inputs.push(input);
        outputs.push(one_hot_encode(label, 5));
    }

    Ok((
        Array2::from_shape_vec((inputs.len(), 5), inputs.concat())?,
        Array2::from_shape_vec((outputs.len(), 5), outputs.concat())?,
        class_counts,
    ))
}

fn one_hot_encode(label: usize, num_classes: usize) -> Vec<f64> {
    let mut vec = vec![0.0; num_classes];
    vec[label] = 1.0;
    vec
}

fn calculate_class_weights(class_counts: &[usize; 5]) -> Vec<f64> {
    let total = class_counts.iter().sum::<usize>() as f64;
    class_counts.iter()
        .map(|&count| total / (class_counts.len() as f64 * count as f64))
        .collect()
}

fn relu(x: &Array2<f64>) -> Array2<f64> {
    x.mapv(|v| v.max(0.0))
}

fn relu_derivative(x: &Array2<f64>) -> Array2<f64> {
    x.mapv(|v| if v > 0.0 { 1.0 } else { 0.0 })
}

fn softmax(x: &Array2<f64>) -> Array2<f64> {
    let max_x = x.fold_axis(Axis(1), f64::NEG_INFINITY, |&a, &b| a.max(b));
    let exp_x = (x - &max_x.insert_axis(Axis(1))).mapv(f64::exp);
    let sum_exp_x = exp_x.sum_axis(Axis(1)).insert_axis(Axis(1));
    exp_x / sum_exp_x
}

fn weighted_cross_entropy(y_true: &Array2<f64>, y_pred: &Array2<f64>, weights: &[f64]) -> f64 {
    let mut loss = 0.0;
    for i in 0..y_true.shape()[0] {
        for j in 0..y_true.shape()[1] {
            loss -= weights[j] * y_true[[i, j]] * (y_pred[[i, j]].max(1e-15)).ln();
        }
    }
    loss / y_true.shape()[0] as f64
}

fn calculate_accuracy(y_true: &Array2<f64>, y_pred: &Array2<f64>) -> f64 {
    let predictions = y_pred.map_axis(Axis(1), |row| {
        row.iter().enumerate().max_by(|a, b| a.1.partial_cmp(b.1).unwrap()).unwrap().0
    });
    let true_labels = y_true.map_axis(Axis(1), |row| {
        row.iter().enumerate().max_by(|a, b| a.1.partial_cmp(b.1).unwrap()).unwrap().0
    });
    predictions.iter().zip(true_labels.iter())
        .filter(|(p, t)| p == t)
        .count() as f64 / predictions.len() as f64
}

// === PREDICTION INTERFACE ===
fn run_prediction_loop(model: &TrainedModel) -> Result<(), Box<dyn Error>> {
    loop {
        println!("\n🔮 Enter machine parameters (or 'q' to quit):");

        let air_temp = match get_input("🌡  Air temperature [K]: ") {
            Some(v) => v,
            None => break,
        };

        let process_temp = get_input("🔥 Process temperature [K]: ").unwrap();
        let rotational_speed = get_input("🌀 Rotational speed [rpm]: ").unwrap();
        let torque = get_input("⚙  Torque [Nm]: ").unwrap();
        let tool_wear = get_input("🛠  Tool wear [min]: ").unwrap();

        let result = predict(
            air_temp, process_temp, rotational_speed, torque, tool_wear,
            &model.network, &model.x_mean, &model.x_std,
        );

        print_prediction_result(&result);
    }
    Ok(())
}

fn get_input(prompt: &str) -> Option<f64> {
    print!("{}", prompt);
    io::stdout().flush().unwrap();

    let mut input = String::new();
    io::stdin().read_line(&mut input).unwrap();

    if input.trim().eq_ignore_ascii_case("q") {
        return None;
    }

    match input.trim().parse() {
        Ok(num) => Some(num),
        Err(_) => {
            println!("⚠  Please enter a valid number");
            get_input(prompt)
        }
    }
}

fn predict(
    air_temp: f64,
    process_temp: f64,
    rotational_speed: f64,
    torque: f64,
    tool_wear: f64,
    nn: &NeuralNetwork,
    x_mean: &Array1<f64>,
    x_std: &Array1<f64>,
) -> PredictionResult {
    let input = array![[air_temp, process_temp, rotational_speed, torque, tool_wear]];
    let input_norm = (input - x_mean) / x_std;

    let (_, _, output) = nn.forward(&input_norm);
    let probs = output.row(0).to_vec();

    let class = probs.iter()
        .enumerate()
        .max_by(|a, b| a.1.partial_cmp(b.1).unwrap())
        .unwrap()
        .0;

    PredictionResult {
        class,
        probabilities: probs,
    }
}

fn print_prediction_result(result: &PredictionResult) {
    let labels = [
        "No Failure",
        "Heat Dissipation Failure",
        "Power Failure",
        "Random Failures",
        "Tool Wear Failure",
    ];
    println!("\n🔍 Prediction: {}", labels[result.class]);
    println!("📊 Probabilities:");
    for (i, prob) in result.probabilities.iter().enumerate() {
        println!("  {}: {:.2}%", labels[i], prob * 100.0);
    }
}

// === PLOT TRAINING CURVE ===
fn create_training_plot(history: &TrainingHistory, path: &str) -> Result<(), Box<dyn Error>> {
    // Create the drawing area
    let root = BitMapBackend::new(path, (800, 600)).into_drawing_area();
    root.fill(&WHITE)?;

    // Split into two sub-areas for loss and accuracy
    let (loss_area, acc_area) = root.split_vertically(300);

    // Get final values
    let final_loss = history.losses.last().unwrap();
    let final_accuracy = history.accuracies.last().unwrap();

    // ===== LOSS PLOT =====
    let mut loss_ctx = ChartBuilder::on(&loss_area)
        .caption(format!("✅ Final Test Loss: {:.4}", final_loss), ("sans-serif", 20).into_font())
        .margin(10)
        .x_label_area_size(30)
        .y_label_area_size(40)
        .build_cartesian_2d(
            0..*history.epochs.last().unwrap(),
            0.0..1.4,
        )?;

    loss_ctx.configure_mesh()
        .x_labels(10)
        .y_labels(8)
        .x_desc("Epoch")
        .y_desc("Loss")
        .draw()?;

    loss_ctx.draw_series(LineSeries::new(
        history.epochs.iter().zip(history.losses.iter()).map(|(&x, &y)| (x, y)),
        &RED,
    ))?.label("Loss")
    .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &RED));

    // ===== ACCURACY PLOT =====
    let mut acc_ctx = ChartBuilder::on(&acc_area)
        .caption(format!("✅ Final Test Accuracy: {:.4}", final_accuracy), ("sans-serif", 20).into_font())
        .margin(10)
        .x_label_area_size(30)
        .y_label_area_size(40)
        .build_cartesian_2d(
            0..*history.epochs.last().unwrap(),
            0.0..1.0,
        )?;

    acc_ctx.configure_mesh()
        .x_labels(10)
        .y_labels(10)
        .x_desc("Epoch")
        .y_desc("Accuracy")
        .draw()?;

    acc_ctx.draw_series(LineSeries::new(
        history.epochs.iter().zip(history.accuracies.iter()).map(|(&x, &y)| (x, y)),
        &BLUE,
    ))?.label("Accuracy")
    .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &BLUE));

    // Configure legends
    loss_ctx.configure_series_labels()
        .background_style(&WHITE.mix(0.8))
        .border_style(&BLACK)
        .draw()?;

    acc_ctx.configure_series_labels()
        .background_style(&WHITE.mix(0.8))
        .border_style(&BLACK)
        .draw()?;

    Ok(())
}