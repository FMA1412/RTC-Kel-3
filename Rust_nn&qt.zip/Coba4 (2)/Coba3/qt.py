import sys
import os
import numpy as np
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
                            QPushButton, QLineEdit, QLabel, QFileDialog, QMessageBox,
                            QProgressBar, QGroupBox, QTabWidget, QSplitter)
from PyQt5.QtGui import QValidator, QPixmap, QFont
from PyQt5 import QtGui
from PyQt5.QtCore import Qt, pyqtSignal, QThread
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from ctypes import CDLL, c_char_p, c_int, c_double, POINTER, Structure, c_float, CFUNCTYPE
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Arrow

# Load the Rust library
lib_path = os.path.join(os.path.dirname(__file__), 'target/release/libpredictive_maintenance.so')
rust_lib = CDLL(lib_path)

# Define C structures to match Rust
class PredictionResult(Structure):
    _fields_ = [
        ("class", c_int),
        ("probabilities", POINTER(c_double)),
        ("probabilities_len", c_int)
    ]

# Define function prototypes
rust_lib.train_and_save_model.argtypes = [
    c_char_p,  # csv_path
    c_char_p,  # model_path
    c_char_p,  # plot_path
    c_int      # epochs
]
rust_lib.train_and_save_model.restype = c_int

rust_lib.load_model.argtypes = [c_char_p]
rust_lib.load_model.restype = POINTER(c_int)

rust_lib.free_model.argtypes = [POINTER(c_int)]
rust_lib.free_model.restype = None

rust_lib.predict_failure.argtypes = [
    POINTER(c_int),  # model
    c_double,  # air_temp
    c_double,  # process_temp
    c_double,  # rotational_speed
    c_double,  # torque
    c_double   # tool_wear
]
rust_lib.predict_failure.restype = POINTER(PredictionResult)

rust_lib.free_prediction_result.argtypes = [POINTER(PredictionResult)]
rust_lib.free_prediction_result.restype = None

rust_lib.get_prediction_class.argtypes = [POINTER(PredictionResult)]
rust_lib.get_prediction_class.restype = c_int

rust_lib.get_prediction_probability.argtypes = [POINTER(PredictionResult), c_int]
rust_lib.get_prediction_probability.restype = c_double

class TrainingThread(QThread):
    update_progress = pyqtSignal(int)
    training_complete = pyqtSignal(bool)
    update_plot = pyqtSignal(int, float, float)  # epoch, accuracy, loss
    
    def __init__(self, csv_path, epochs, model_path, plot_path, parent=None):
        super().__init__(parent)
        self.csv_path = csv_path
        self.epochs = epochs
        self.model_path = model_path
        self.plot_path = plot_path
        
    def run(self):
        csv_path_bytes = self.csv_path.encode('utf-8')
        model_path_bytes = self.model_path.encode('utf-8')
        plot_path_bytes = self.plot_path.encode('utf-8')
        
        # Define callback type for Rust
        callback_type = CFUNCTYPE(None, c_int, c_double, c_double)
        
        def training_callback(epoch, accuracy, loss):
            self.update_plot.emit(epoch, accuracy, loss)
            progress = int((epoch / self.epochs) * 100)
            self.update_progress.emit(progress)
        
        callback = callback_type(training_callback)
        
        # Pass the callback to Rust
        rust_lib.set_training_callback(callback)
        
        success = rust_lib.train_and_save_model(
            csv_path_bytes,
            model_path_bytes,
            plot_path_bytes,
            self.epochs
        )
        
        self.training_complete.emit(bool(success))

class PlotCanvas(FigureCanvas):
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        plt.style.use('seaborn')
        fig = Figure(figsize=(width, height), dpi=dpi)
        fig.patch.set_facecolor('#f9f9f9')
        self.axes1 = fig.add_subplot(111)
        self.axes2 = self.axes1.twinx()
        super().__init__(fig)
        self.setParent(parent)
        self.accuracy_data = []
        self.loss_data = []
        self.epochs = []

    def update_plot(self, epoch, accuracy, loss):
        self.epochs.append(epoch)
        self.accuracy_data.append(accuracy * 100.0)
        self.loss_data.append(loss)
        self.axes1.clear()
        self.axes2.clear()
        
        # Customize plot appearance
        self.axes1.set_facecolor('#f9f9f9')
        self.axes2.set_facecolor('#f9f9f9')
        
        # Plot accuracy
        acc_line, = self.axes1.plot(self.epochs, self.accuracy_data, 'r-', linewidth=2, label='Accuracy (%)')
        self.axes1.set_xlabel('Epoch', fontsize=10)
        self.axes1.set_ylabel('Accuracy (%)', color='r', fontsize=10)
        self.axes1.tick_params(axis='y', colors='r')
        self.axes1.grid(True, linestyle='--', alpha=0.7)
        
        # Plot loss
        loss_line, = self.axes2.plot(self.epochs, self.loss_data, 'b-', linewidth=2, label='Loss')
        self.axes2.set_ylabel('Loss', color='b', fontsize=10)
        self.axes2.tick_params(axis='y', colors='b')
        
        # Title and legend
        self.axes1.set_title('Training Progress', fontsize=12, pad=20)
        self.axes1.legend(handles=[acc_line, loss_line], loc='upper right', fontsize=9)
        
        self.draw()

    def reset(self):
        self.epochs = []
        self.accuracy_data = []
        self.loss_data = []
        self.axes1.clear()
        self.axes2.clear()
        self.draw()

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        self.model = None
        self.model_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "trained_model.bin")
        
        self.setWindowTitle("Machine Failure Prediction System")
        self.setGeometry(100, 100, 1200, 850)
        
        # Set application style
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f5f5f5;
            }
            QGroupBox {
                font-size: 12px;
                font-weight: bold;
                border: 1px solid #ccc;
                border-radius: 5px;
                margin-top: 10px;
                padding-top: 15px;
                background-color: white;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 3px;
            }
            QPushButton {
                background-color: #4CAF50;
                border: none;
                color: white;
                padding: 8px 16px;
                text-align: center;
                text-decoration: none;
                font-size: 12px;
                margin: 4px 2px;
                border-radius: 4px;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:disabled {
                background-color: #cccccc;
            }
            QLabel {
                font-size: 12px;
            }
            QLineEdit {
                padding: 5px;
                border: 1px solid #ccc;
                border-radius: 4px;
                background-color: white;
            }
            QProgressBar {
                border: 1px solid #ccc;
                border-radius: 4px;
                text-align: center;
                height: 20px;
            }
            QProgressBar::chunk {
                background-color: #4CAF50;
                width: 10px;
            }
            #predictionResult {
                font-size: 14px;
                font-weight: bold;
                color: #d9534f;
                padding: 8px;
                border-radius: 4px;
                background-color: #f9f9f9;
                border: 1px solid #ddd;
            }
            #probabilitiesLabel {
                font-size: 12px;
                padding: 8px;
                border-radius: 4px;
                background-color: #f9f9f9;
                border: 1px solid #ddd;
            }
            .metric-label {
                font-weight: bold;
                color: #333;
            }
            .accuracy-value {
                color: #5cb85c;
            }
            .loss-value {
                color: #d9534f;
            }
        """)
        
        self.main_widget = QWidget()
        self.setCentralWidget(self.main_widget)
        
        main_layout = QVBoxLayout(self.main_widget)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(10)
        
        # Header
        header = QLabel("Machine Failure Prediction System")
        header.setStyleSheet("""
            font-size: 18px;
            font-weight: bold;
            color: #333;
            padding: 10px;
            border-bottom: 2px solid #4CAF50;
        """)
        header.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(header)
        
        # Create a horizontal splitter for main content
        self.splitter = QSplitter(Qt.Horizontal)
        
        # Left side (main content)
        self.left_widget = QWidget()
        self.left_layout = QVBoxLayout(self.left_widget)
        self.left_layout.setContentsMargins(5, 5, 5, 5)
        self.left_layout.setSpacing(10)
        
        # Right side (prediction panel)
        self.right_widget = QWidget()
        self.right_layout = QVBoxLayout(self.right_widget)
        self.right_layout.setContentsMargins(5, 5, 5, 5)
        self.right_layout.setSpacing(10)
        
        self.create_data_loading_section()
        self.create_training_parameters_section()
        self.create_progress_section()
        self.create_visualization_section()
        self.create_prediction_section()
        
        # Add widgets to splitter
        self.splitter.addWidget(self.left_widget)
        self.splitter.addWidget(self.right_widget)
        
        # Set splitter sizes (left side takes more space)
        self.splitter.setSizes([800, 400])
        
        # Add splitter to main layout
        main_layout.addWidget(self.splitter)
        
        # Status bar
        self.statusBar().showMessage("Ready")
        
        # Enable predict button if model exists
        self.predict_button.setEnabled(os.path.exists(self.model_path))
        
        # Load model if it exists
        if os.path.exists(self.model_path):
            self.load_model()
    
    def create_data_loading_section(self):
        group = QGroupBox("1. Data Loading")
        layout = QHBoxLayout()
        layout.setContentsMargins(8, 15, 8, 8)
        
        self.load_button = QPushButton("Load CSV")
        self.load_button.clicked.connect(self.load_csv)
        self.load_button.setStyleSheet("background-color: #5bc0de;")
        self.load_button.setToolTip("Load training data CSV file")
        
        self.csv_label = QLabel("No file selected")
        self.csv_label.setStyleSheet("font-weight: normal; color: #555;")
        
        self.data_count_label = QLabel("Data count: 0")
        self.data_count_label.setStyleSheet("font-weight: normal; color: #337ab7;")
        
        layout.addWidget(self.load_button)
        layout.addWidget(self.csv_label)
        layout.addWidget(self.data_count_label)
        layout.addStretch()
        
        group.setLayout(layout)
        self.left_layout.addWidget(group)
    
    def create_training_parameters_section(self):
        group = QGroupBox("2. Training Parameters")
        layout = QHBoxLayout()
        layout.setContentsMargins(8, 15, 8, 8)
        
        epoch_layout = QVBoxLayout()
        epoch_label = QLabel("Training Epochs:")
        self.epoch_input = QLineEdit("1000")
        self.epoch_input.setValidator(QtGui.QIntValidator(1, 10000))
        self.epoch_input.setToolTip("Number of training iterations")
        epoch_layout.addWidget(epoch_label)
        epoch_layout.addWidget(self.epoch_input)
        
        self.train_button = QPushButton("Train Model")
        self.train_button.clicked.connect(self.start_training)
        self.train_button.setEnabled(False)
        self.train_button.setStyleSheet("background-color: #5cb85c;")
        self.train_button.setToolTip("Start model training with current parameters")
        
        layout.addLayout(epoch_layout)
        layout.addWidget(self.train_button)
        layout.addStretch()
        
        group.setLayout(layout)
        self.left_layout.addWidget(group)
    
    def create_progress_section(self):
        group = QGroupBox("3. Training Progress")
        layout = QVBoxLayout()
        layout.setContentsMargins(8, 15, 8, 8)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setFormat("%p%")
        
        # Create metrics display
        metrics_group = QGroupBox("Training Metrics")
        metrics_group.setStyleSheet("font-size: 11px; font-weight: normal;")
        metrics_layout = QGridLayout()
        metrics_layout.setContentsMargins(5, 10, 5, 5)
        
        # Status row
        self.status_label = QLabel("Status: Ready")
        self.status_label.setStyleSheet("font-weight: bold;")
        metrics_layout.addWidget(self.status_label, 0, 0, 1, 2)
        
        # Epoch row
        epoch_title = QLabel("Current Epoch:")
        epoch_title.setStyleSheet("font-weight: bold;")
        self.epoch_label = QLabel("0")
        metrics_layout.addWidget(epoch_title, 1, 0)
        metrics_layout.addWidget(self.epoch_label, 1, 1)
        
        # Accuracy row
        accuracy_title = QLabel("Accuracy:")
        accuracy_title.setStyleSheet("font-weight: bold;")
        self.accuracy_label = QLabel("0.00%")
        self.accuracy_label.setStyleSheet("color: #5cb85c;")
        metrics_layout.addWidget(accuracy_title, 2, 0)
        metrics_layout.addWidget(self.accuracy_label, 2, 1)
        
        # Loss row
        loss_title = QLabel("Loss:")
        loss_title.setStyleSheet("font-weight: bold;")
        self.loss_label = QLabel("0.0000")
        self.loss_label.setStyleSheet("color: #d9534f;")
        metrics_layout.addWidget(loss_title, 3, 0)
        metrics_layout.addWidget(self.loss_label, 3, 1)
        
        metrics_group.setLayout(metrics_layout)
        
        layout.addWidget(self.progress_bar)
        layout.addWidget(metrics_group)
        
        group.setLayout(layout)
        self.left_layout.addWidget(group)
    
    def create_visualization_section(self):
        group = QGroupBox("4. Training Visualization")
        layout = QVBoxLayout()
        layout.setContentsMargins(5, 15, 5, 5)
        
        self.canvas = PlotCanvas(self, width=8, height=4, dpi=100)
        
        layout.addWidget(self.canvas)
        group.setLayout(layout)
        self.left_layout.addWidget(group)
    
    def create_prediction_section(self):
        group = QGroupBox("Machine Failure Prediction")
        group.setStyleSheet("""
            QGroupBox {
                font-size: 14px;
                border: 2px solid #5bc0de;
                background-color: #f0f8ff;
            }
        """)
        layout = QVBoxLayout()
        layout.setContentsMargins(10, 20, 10, 10)
        
        # Input fields
        input_group = QGroupBox("Input Parameters")
        input_group.setStyleSheet("font-size: 12px; font-weight: normal; background-color: white;")
        input_layout = QVBoxLayout()
        input_layout.setContentsMargins(8, 15, 8, 8)
        
        def create_input_field(label_text, placeholder, tooltip=""):
            hbox = QHBoxLayout()
            label = QLabel(label_text)
            label.setFixedWidth(150)
            label.setStyleSheet("font-weight: bold;")
            input_field = QLineEdit()
            input_field.setPlaceholderText(placeholder)
            input_field.setStyleSheet("font-weight: normal;")
            input_field.setToolTip(tooltip)
            hbox.addWidget(label)
            hbox.addWidget(input_field)
            return hbox, input_field
        
        self.air_temp_layout, self.air_temp_input = create_input_field(
            "Air Temperature [K]:", "300.0", "Temperature of the surrounding air")
        self.process_temp_layout, self.process_temp_input = create_input_field(
            "Process Temperature [K]:", "310.0", "Temperature of the manufacturing process")
        self.rot_speed_layout, self.rot_speed_input = create_input_field(
            "Rotational Speed [rpm]:", "1500", "Speed of the rotating component")
        self.torque_layout, self.torque_input = create_input_field(
            "Torque [Nm]:", "50.0", "Torque applied to the tool")
        self.tool_wear_layout, self.tool_wear_input = create_input_field(
            "Tool Wear [min]:", "100", "Duration of tool usage in minutes")
        
        input_layout.addLayout(self.air_temp_layout)
        input_layout.addLayout(self.process_temp_layout)
        input_layout.addLayout(self.rot_speed_layout)
        input_layout.addLayout(self.torque_layout)
        input_layout.addLayout(self.tool_wear_layout)
        input_group.setLayout(input_layout)
        
        # Predict button
        self.predict_button = QPushButton("Predict Failure")
        self.predict_button.clicked.connect(self.predict)
        self.predict_button.setStyleSheet("""
            background-color: #d9534f;
            font-weight: bold;
            font-size: 14px;
            padding: 10px;
        """)
        self.predict_button.setToolTip("Predict machine failure based on input parameters")
        
        # Results display
        result_group = QGroupBox("Prediction Results")
        result_group.setStyleSheet("font-size: 12px; font-weight: normal; background-color: white;")
        result_layout = QVBoxLayout()
        result_layout.setContentsMargins(8, 15, 8, 8)
        
        self.prediction_result = QLabel("Prediction: -")
        self.prediction_result.setObjectName("predictionResult")
        self.prediction_result.setAlignment(Qt.AlignCenter)
        
        self.probabilities_label = QLabel("Probabilities: -")
        self.probabilities_label.setObjectName("probabilitiesLabel")
        
        result_layout.addWidget(self.prediction_result)
        result_layout.addWidget(self.probabilities_label)
        result_group.setLayout(result_layout)
        
        # Add widgets to layout
        layout.addWidget(input_group)
        layout.addWidget(self.predict_button)
        layout.addWidget(result_group)
        layout.addStretch()
        
        group.setLayout(layout)
        self.right_layout.addWidget(group)

    def load_csv(self):
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getOpenFileName(
            self, "Open CSV File", "", "CSV Files (*.csv)", options=options)
        
        if file_name:
            self.csv_path = file_name
            self.csv_label.setText(os.path.basename(file_name))
            self.csv_label.setToolTip(file_name)
            
            try:
                with open(file_name, 'r') as f:
                    self.data_count = sum(1 for _ in f) - 1
                    self.data_count_label.setText(f"Data count: {self.data_count}")
                    
                    if self.data_count > 0:
                        self.train_button.setEnabled(True)
                        self.statusBar().showMessage(f"Loaded {self.data_count} records from {os.path.basename(file_name)}")
                    else:
                        QMessageBox.warning(self, "Warning", "The selected CSV file has no data rows.")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to read CSV file: {str(e)}")
                self.statusBar().showMessage("Error loading CSV file")
    
    def start_training(self):
        if not hasattr(self, 'csv_path'):
            QMessageBox.warning(self, "Warning", "Please load a CSV file first.")
            return
        
        try:
            epochs = int(self.epoch_input.text())
        except ValueError:
            QMessageBox.warning(self, "Warning", "Please enter a valid number for epochs.")
            return
        
        # Create paths in project directory
        project_dir = os.path.dirname(os.path.abspath(__file__))
        plot_path = os.path.join(project_dir, "training_plot.png")
        
        self.progress_bar.setValue(0)
        self.status_label.setText("Training started...")
        self.statusBar().showMessage("Training started...")
        self.canvas.reset()
        
        self.train_button.setEnabled(False)
        self.load_button.setEnabled(False)
        
        self.training_thread = TrainingThread(
            self.csv_path,
            epochs,
            self.model_path,
            plot_path
        )
        self.training_thread.update_progress.connect(self.update_progress)
        self.training_thread.update_plot.connect(self.update_training_plot)
        self.training_thread.training_complete.connect(self.training_finished)
        self.training_thread.start()
    
    def update_progress(self, value):
        self.progress_bar.setValue(value)
    
    def update_training_plot(self, epoch, accuracy, loss):
        self.epoch_label.setText(f"{epoch}")
        self.accuracy_label.setText(f"{accuracy*100:.2f}%")
        self.loss_label.setText(f"{loss:.4f}")
        self.canvas.update_plot(epoch, accuracy, loss)
    
    def training_finished(self, success):
        self.train_button.setEnabled(True)
        self.load_button.setEnabled(True)
        
        if success:
            self.status_label.setText("Training completed!")
            self.statusBar().showMessage("Training completed successfully!")
            self.progress_bar.setValue(100)
            QMessageBox.information(self, "Success", "Model trained and saved successfully!")
            self.load_model()
        else:
            self.status_label.setText("Training failed")
            self.statusBar().showMessage("Training failed")
            QMessageBox.critical(self, "Error", "Training failed. Check your data and parameters.")
    
    def load_model(self):
        if os.path.exists(self.model_path):
            model_path_bytes = self.model_path.encode('utf-8')
            self.model = rust_lib.load_model(model_path_bytes)
            self.predict_button.setEnabled(True)
            self.statusBar().showMessage("Model loaded successfully")
    
    def predict(self):
        if self.model is None:
            QMessageBox.warning(self, "Warning", "No trained model found. Please train the model first.")
            return
        
        try:
            # Get input values
            air_temp = float(self.air_temp_input.text())
            process_temp = float(self.process_temp_input.text())
            rot_speed = float(self.rot_speed_input.text())
            torque = float(self.torque_input.text())
            tool_wear = float(self.tool_wear_input.text())
            
            # Call Rust prediction function
            prediction_ptr = rust_lib.predict_failure(
                self.model,
                air_temp,
                process_temp,
                rot_speed,
                torque,
                tool_wear
            )
            
            if not prediction_ptr:
                QMessageBox.critical(self, "Error", "Prediction failed")
                return
            
            # Get prediction class
            pred_class = rust_lib.get_prediction_class(prediction_ptr)
            
            # Get probabilities for each class
            probs = []
            for i in range(5):
                probs.append(rust_lib.get_prediction_probability(prediction_ptr, i))
            
            # Map class to failure type
            failure_types = [
                "No Failure",
                "Heat Dissipation Failure",
                "Power Failure",
                "Random Failures",
                "Tool Wear Failure"
            ]
            
            # Update UI
            result_text = f"Prediction: {failure_types[pred_class]}"
            if pred_class == 0:
                self.prediction_result.setStyleSheet("color: #5cb85c;")
            else:
                self.prediction_result.setStyleSheet("color: #d9534f;")
            self.prediction_result.setText(result_text)
            
            # Format probabilities
            prob_text = "<b>Probabilities:</b><br>"
            for i, (prob, failure) in enumerate(zip(probs, failure_types)):
                prob_text += f"{failure}: {prob*100:.1f}%<br>"
            
            self.probabilities_label.setText(prob_text)
            
            # Free memory
            rust_lib.free_prediction_result(prediction_ptr)
            
        except ValueError:
            QMessageBox.warning(self, "Warning", "Please enter valid numbers for all input fields")
    
    def closeEvent(self, event):
        # Free model when closing
        if self.model is not None:
            rust_lib.free_model(self.model)
        event.accept()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Set application font
    font = QFont()
    font.setFamily("Segoe UI")
    font.setPointSize(10)
    app.setFont(font)
    
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())