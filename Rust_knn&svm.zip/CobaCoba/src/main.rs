use linfa::prelude::*;
use linfa_logistic::MultiLogisticRegression;
use ndarray::{Array1, Array2, Axis,};
use csv::ReaderBuilder;
use std::fs::File;
use rand::thread_rng;
use rand::seq::SliceRandom;
use std::io::{self, Write};
use std::collections::HashMap;

fn euclidean_distance(a: &Array1<f64>, b: &Array1<f64>) -> f64 {
    a.iter().zip(b.iter()).map(|(x, y)| (x - y).powi(2)).sum::<f64>().sqrt()
}

fn failure_to_label(failure: &str) -> usize {
    match failure {
        "No Failure" => 0,
        "Heat Dissipation Failure" => 1,
        "Power Failure" => 2,
        "Random Failures" => 3,
        "Tool Wear Failure" => 4,
        _ => 0,
    }
}

fn label_to_failure(label: usize) -> &'static str {
    match label {
        0 => "No Failure",
        1 => "Heat Dissipation Failure",
        2 => "Power Failure",
        3 => "Random Failures",
        4 => "Tool Wear Failure",
        _ => "Unknown",
    }
}

fn knn_predict(
    train: &Array2<f64>,
    train_labels: &Array1<usize>,
    test: &Array2<f64>,
    k: usize,
) -> Array1<usize> {
    let mut predictions = Array1::zeros(test.nrows());

    for (i, test_sample) in test.axis_iter(Axis(0)).enumerate() {
        let distances = train.axis_iter(Axis(0))
            .map(|train_sample| euclidean_distance(&train_sample.to_owned(), &test_sample.to_owned()))
            .collect::<Vec<_>>();

        let mut nearest_indices = (0..distances.len()).collect::<Vec<_>>();
        nearest_indices.sort_by(|&a, &b| distances[a].partial_cmp(&distances[b]).unwrap());
        let nearest_indices = &nearest_indices[..k];

        let mut label_counts = HashMap::new();
        for &idx in nearest_indices {
            let label = train_labels[idx];
            *label_counts.entry(label).or_insert(0) += 1;
        }

        let prediction = label_counts.into_iter().max_by_key(|&(_, count)| count).unwrap().0;
        predictions[i] = prediction;
    }

    predictions
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    // 1. Baca dataset
    let file = File::open("Dataset/predictive_maintenance.csv")?;
    let mut rdr = ReaderBuilder::new().has_headers(true).from_reader(file);
    let mut records: Vec<_> = rdr.records().collect::<Result<_, _>>()?;
    let mut rng = thread_rng();
    records.shuffle(&mut rng);

    // 2. Ambil fitur dan label
    let mut features = Vec::new();
    let mut labels = Vec::new();

    for record in &records {
        let feat: Vec<f64> = vec![
            record[0].parse::<f64>()?, // Air temperature [K]
            record[1].parse::<f64>()?, // Process temperature [K]
            record[2].parse::<f64>()?, // Rotational speed [rpm]
            record[3].parse::<f64>()?, // Torque [Nm]
            record[4].parse::<f64>()?, // Tool wear [min]
        ];
        features.push(feat);

        let label = failure_to_label(record[5].trim()); // Kolom "Failure Type" di indeks ke-5
        labels.push(label);
    }

    let mut features = Array2::from_shape_vec((features.len(), 5), features.concat())?;
    let labels = Array1::from_vec(labels);

    // 3. Normalisasi fitur
    for mut col in features.axis_iter_mut(Axis(1)) {
        let mean = col.mean().unwrap();
        let std = col.std(0.0);
        col.iter_mut().for_each(|x| *x = (*x - mean) / std);
    }

    // 4. Bagi data 80-20
    let (train, test) = Dataset::new(features, labels).split_with_ratio(0.8);

    // 5. Train SVM
    let svm_model = MultiLogisticRegression::default()
        .max_iterations(100)
        .fit(&train)?;

    let svm_pred = svm_model.predict(&test);
    let svm_acc = svm_pred.iter().zip(test.targets().iter())
        .filter(|(p, t)| p == t).count() as f64 / test.nsamples() as f64;

    println!("Akurasi Model SVM: {:.2}%", svm_acc * 100.0);

    // 6. KNN manual
    let knn_pred = knn_predict(train.records(), train.targets(), test.records(), 5);
    let knn_acc = knn_pred.iter().zip(test.targets().iter())
        .filter(|(p, t)| p == t).count() as f64 / test.nsamples() as f64;

    println!("Akurasi Model KNN: {:.2}%", knn_acc * 100.0);

    // 7. Ambil 10 data untuk demo prediksi
    let mut idx: Vec<usize> = (0..test.nsamples()).collect();
    idx.shuffle(&mut rng);
    let selected = &idx[..10];

    let test_samples = test.records().select(Axis(0), selected);
    let test_labels = test.targets().select(Axis(0), selected);

    let svm_predictions = svm_model.predict(&test_samples);
    let knn_predictions = knn_predict(train.records(), train.targets(), &test_samples, 5);

    println!("\nHasil Prediksi 10 Sampel:");
    for (i, ((svm, knn), actual)) in svm_predictions.iter()
        .zip(knn_predictions.iter())
        .zip(test_labels.iter())
        .enumerate()
    {
        println!(
            "Sampel {}: SVM = {}, KNN = {}, Aktual = {}",
            i + 1,
            label_to_failure(*svm),
            label_to_failure(*knn),
            label_to_failure(*actual),
        );
    }

    // 8. Input manual
    println!("\nMasukkan data manual untuk prediksi:");
    let mut manual_features = Vec::new();
    let mut input = String::new();

    let prompts = [
        "Air temperature [K]",
        "Process temperature [K]",
        "Rotational speed [rpm]",
        "Torque [Nm]",
        "Tool wear [min]",
    ];

    for prompt in &prompts {
        print!("{}: ", prompt);
        io::stdout().flush()?;
        io::stdin().read_line(&mut input)?;
        manual_features.push(input.trim().parse::<f64>()?);
        input.clear();
    }

    let mut manual_array = Array2::from_shape_vec((1, 5), manual_features)?;
    for (i, mut col) in manual_array.axis_iter_mut(Axis(1)).enumerate() {
        let train_col = train.records().column(i);
        let mean = train_col.mean().unwrap();
        let std = train_col.std(0.0);
        col.iter_mut().for_each(|x| *x = (*x - mean) / std);
    }

    let svm_manual = svm_model.predict(&manual_array);
    let knn_manual = knn_predict(train.records(), train.targets(), &manual_array, 5);

    println!("\nPrediksi Input Manual:");
    println!("SVM: {}", label_to_failure(svm_manual[0]));
    println!("KNN: {}", label_to_failure(knn_manual[0]));

    Ok(())
}
